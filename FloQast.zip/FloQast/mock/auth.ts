import type { Request, Response, NextFunction } from 'express';
import type { AuthRole } from '../types/models';

declare global {
  namespace Express {
    interface Request {
      auth?: { role: AuthRole };
    }
  }
}

const TOKEN_ROLES: Record<string, AuthRole> = {
  [process.env.AUTH_TOKEN ?? 'valid-test-token']: 'admin',
  'admin-token': 'admin',
  'user-token': 'user',
};

export function authenticate(req: Request, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Missing authentication token',
      code: 'UNAUTHORIZED',
    });
    return;
  }

  const token = header.slice('Bearer '.length).trim();
  const role = TOKEN_ROLES[token];

  if (!role) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Invalid authentication token',
      code: 'UNAUTHORIZED',
    });
    return;
  }

  req.auth = { role };
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (req.auth?.role !== 'admin') {
    res.status(403).json({
      error: 'Forbidden',
      message: 'Admin role required',
      code: 'FORBIDDEN',
    });
    return;
  }
  next();
}
