import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import { authenticate, requireAdmin } from './auth';
import { createTransaction, createUser, getTransactions, getUser, resetStore } from './handlers';

dotenv.config();

const app = express();
const port = Number(process.env.PORT ?? 3000);

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
});

app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'mock', 'public')));

app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[mock] ${req.method} ${req.path}`);
  }
  next();
});

app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.post('/api/users', authenticate, createUser);
app.get('/api/users/:id', authenticate, getUser);
app.post('/api/transactions', authenticate, createTransaction);
app.get('/api/transactions/:userId', authenticate, getTransactions);

app.post('/api/test/reset', authenticate, requireAdmin, resetStore);

app.use((err: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err instanceof SyntaxError) {
    res.status(400).json({
      error: 'Bad Request',
      message: 'Invalid JSON payload',
      code: 'INVALID_JSON',
    });
    return;
  }
  next(err);
});

app.listen(port, () => {
  console.log(`[mock] Fintech mock server listening on http://localhost:${port}`);
});
