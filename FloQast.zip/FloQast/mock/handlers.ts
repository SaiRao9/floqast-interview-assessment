import type { Request, Response } from 'express';
import { ACCOUNT_TYPES, TRANSACTION_TYPES } from '../types/models';
import type { AccountType, CreateTransactionRequest, CreateUserRequest, TransactionType } from '../types/models';
import { createId, isUuid, store } from './store';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isEmptyBody(body: unknown): boolean {
  return body === undefined || body === null || (typeof body === 'object' && Object.keys(body as object).length === 0);
}

function badRequest(res: Response, message: string, code = 'BAD_REQUEST'): void {
  res.status(400).json({ error: 'Bad Request', message, code });
}

export function createUser(req: Request, res: Response): void {
  if (isEmptyBody(req.body)) {
    badRequest(res, 'Request body is required', 'MISSING_BODY');
    return;
  }

  const { name, email, accountType } = req.body as Partial<CreateUserRequest>;

  if (typeof name !== 'string' || name.trim().length === 0) {
    badRequest(res, 'name is required', 'VALIDATION_ERROR');
    return;
  }

  if (typeof email !== 'string' || email.trim().length === 0) {
    badRequest(res, 'email is required', 'VALIDATION_ERROR');
    return;
  }

  if (!EMAIL_RE.test(email.trim())) {
    badRequest(res, 'Invalid email format', 'INVALID_EMAIL');
    return;
  }

  if (typeof accountType !== 'string' || accountType.trim().length === 0) {
    badRequest(res, 'accountType is required', 'VALIDATION_ERROR');
    return;
  }

  if (!ACCOUNT_TYPES.includes(accountType as AccountType)) {
    badRequest(
      res,
      `Invalid accountType. Must be one of: ${ACCOUNT_TYPES.join(', ')}`,
      'INVALID_ACCOUNT_TYPE',
    );
    return;
  }

  if (store.getUserByEmail(email.trim())) {
    res.status(409).json({
      error: 'Conflict',
      message: 'Email already exists',
      code: 'DUPLICATE_EMAIL',
    });
    return;
  }

  const user = {
    id: createId(),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    accountType: accountType as AccountType,
    createdAt: new Date().toISOString(),
  };

  store.addUser(user);
  res.status(201).json(user);
}

export function getUser(req: Request, res: Response): void {
  const { id } = req.params;

  if (!id || !isUuid(id)) {
    badRequest(res, 'Invalid user ID format', 'INVALID_USER_ID');
    return;
  }

  const user = store.getUserById(id);
  if (!user) {
    res.status(404).json({
      error: 'Not Found',
      message: 'User not found',
      code: 'USER_NOT_FOUND',
    });
    return;
  }

  res.status(200).json(user);
}

export function createTransaction(req: Request, res: Response): void {
  if (isEmptyBody(req.body)) {
    badRequest(res, 'Request body is required', 'MISSING_BODY');
    return;
  }

  const { userId, amount, type, recipientId } = req.body as Partial<CreateTransactionRequest>;

  if (typeof userId !== 'string' || userId.trim().length === 0) {
    badRequest(res, 'userId is required', 'VALIDATION_ERROR');
    return;
  }

  if (typeof amount !== 'number' || Number.isNaN(amount)) {
    badRequest(res, 'amount must be a valid number', 'INVALID_AMOUNT');
    return;
  }

  if (amount <= 0) {
    badRequest(res, 'amount must be greater than 0', 'INVALID_AMOUNT');
    return;
  }

  if (typeof type !== 'string' || type.trim().length === 0) {
    badRequest(res, 'type is required', 'VALIDATION_ERROR');
    return;
  }

  if (!TRANSACTION_TYPES.includes(type as TransactionType)) {
    badRequest(
      res,
      `Invalid transaction type. Must be one of: ${TRANSACTION_TYPES.join(', ')}`,
      'INVALID_TRANSACTION_TYPE',
    );
    return;
  }

  if (typeof recipientId !== 'string' || recipientId.trim().length === 0) {
    badRequest(res, 'recipientId is required', 'VALIDATION_ERROR');
    return;
  }

  const sender = store.getUserById(userId.trim());
  if (!sender) {
    badRequest(res, 'userId does not exist', 'USER_NOT_FOUND');
    return;
  }

  const recipient = store.getUserById(recipientId.trim());
  if (!recipient) {
    badRequest(res, 'recipientId does not exist', 'RECIPIENT_NOT_FOUND');
    return;
  }

  const transaction = {
    id: createId(),
    userId: userId.trim(),
    amount,
    type: type as TransactionType,
    recipientId: recipientId.trim(),
    status: 'completed' as const,
    createdAt: new Date().toISOString(),
  };

  store.addTransaction(transaction);
  res.status(201).json(transaction);
}

export function getTransactions(req: Request, res: Response): void {
  const { userId } = req.params;

  if (!userId || !isUuid(userId)) {
    badRequest(res, 'Invalid user ID format', 'INVALID_USER_ID');
    return;
  }

  if (!store.getUserById(userId)) {
    res.status(404).json({
      error: 'Not Found',
      message: 'User not found',
      code: 'USER_NOT_FOUND',
    });
    return;
  }

  res.status(200).json(store.getTransactionsByUserId(userId));
}

export function resetStore(req: Request, res: Response): void {
  store.reset();
  res.status(200).json({ message: 'Store reset' });
}
