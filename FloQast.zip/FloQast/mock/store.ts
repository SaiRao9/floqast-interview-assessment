import { randomUUID } from 'crypto';
import type { Transaction, User } from '../types/models';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isUuid(value: string): boolean {
  return UUID_RE.test(value);
}

export function createId(): string {
  return randomUUID();
}

class InMemoryStore {
  private usersById = new Map<string, User>();
  private usersByEmail = new Map<string, User>();
  private transactionsById = new Map<string, Transaction>();
  private transactionsByUserId = new Map<string, Transaction[]>();

  reset(): void {
    this.usersById.clear();
    this.usersByEmail.clear();
    this.transactionsById.clear();
    this.transactionsByUserId.clear();
  }

  addUser(user: User): void {
    this.usersById.set(user.id, user);
    this.usersByEmail.set(user.email.toLowerCase(), user);
  }

  getUserById(id: string): User | undefined {
    return this.usersById.get(id);
  }

  getUserByEmail(email: string): User | undefined {
    return this.usersByEmail.get(email.toLowerCase());
  }

  addTransaction(transaction: Transaction): void {
    this.transactionsById.set(transaction.id, transaction);
    const existing = this.transactionsByUserId.get(transaction.userId) ?? [];
    existing.push(transaction);
    this.transactionsByUserId.set(transaction.userId, existing);
  }

  getTransactionsByUserId(userId: string): Transaction[] {
    return this.transactionsByUserId.get(userId) ?? [];
  }
}

export const store = new InMemoryStore();
