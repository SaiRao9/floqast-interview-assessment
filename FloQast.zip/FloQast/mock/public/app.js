const AUTH_TOKEN = 'valid-test-token';

function $(testId) {
  return document.querySelector(`[data-testid="${testId}"]`);
}

function show(testId, text) {
  const el = $(testId);
  el.textContent = text;
  el.classList.remove('hidden');
}

function hide(testId) {
  const el = $(testId);
  el.textContent = '';
  el.classList.add('hidden');
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function apiPost(path, body) {
  const response = await fetch(path, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${AUTH_TOKEN}`,
    },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

function initRegisterForm() {
  const form = document.getElementById('register-form');
  if (!form) return;

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    hide('success-message');
    hide('error-message');

    const name = $('name-input').value.trim();
    const email = $('email-input').value.trim();
    const accountType = $('account-type-select').value;

    if (!name || !email || !accountType) {
      show('error-message', 'Name, email, and account type are required');
      return;
    }

    if (!isValidEmail(email)) {
      show('error-message', 'Invalid email format');
      return;
    }

    const result = await apiPost('/api/users', { name, email, accountType });
    if (!result.ok) {
      show('error-message', result.data.message || 'Registration failed');
      return;
    }

    show('success-message', `User registered successfully. ID: ${result.data.id}`);
  });
}

function initTransactionForm() {
  const form = document.getElementById('transaction-form');
  if (!form) return;

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    hide('success-message');
    hide('error-message');

    const userId = $('user-id-input').value.trim();
    const amountRaw = $('amount-input').value.trim();
    const type = $('type-select').value;
    const recipientId = $('recipient-id-input').value.trim();
    const amount = Number(amountRaw);

    if (!userId || !amountRaw || !type || !recipientId) {
      show('error-message', 'User ID, amount, type, and recipient ID are required');
      return;
    }

    if (Number.isNaN(amount) || amount <= 0) {
      show('error-message', 'Amount must be a number greater than 0');
      return;
    }

    const result = await apiPost('/api/transactions', { userId, amount, type, recipientId });
    if (!result.ok) {
      show('error-message', result.data.message || 'Transaction failed');
      return;
    }

    show('success-message', `Transaction created successfully. ID: ${result.data.id}`);
  });
}

initRegisterForm();
initTransactionForm();
