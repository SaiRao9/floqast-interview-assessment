export type AccountType = 'basic' | 'standard' | 'premium';
export type TransactionType = 'transfer' | 'deposit' | 'withdrawal';
export type TransactionStatus = 'pending' | 'completed' | 'failed';
export type AuthRole = 'admin' | 'user';

export const ACCOUNT_TYPES: AccountType[] = ['basic', 'standard', 'premium'];
export const TRANSACTION_TYPES: TransactionType[] = ['transfer', 'deposit', 'withdrawal'];

export interface User {
  id: string;
  name: string;
  email: string;
  accountType: AccountType;
  createdAt: string;
}

export interface CreateUserRequest {
  name: string;
  email: string;
  accountType: AccountType;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: TransactionType;
  recipientId: string;
  status: TransactionStatus;
  createdAt: string;
}

export interface CreateTransactionRequest {
  userId: string;
  amount: number;
  type: TransactionType;
  recipientId: string;
}

export interface ErrorBody {
  error: string;
  message: string;
  code?: string;
}
