import { test as base, expect } from '@playwright/test';
import { env } from '../config/env';
import { buildUser } from '../factories/user.factory';
import { TransactionPage } from '../pages/transaction.page';
import { UserRegistrationPage } from '../pages/user-registration.page';
import type { User } from '../types/models';
import { ApiClient } from '../utils/api-client';
import { assertSuccessfulResponse, assertUserResponse, readJson } from '../utils/assertions';

type Fixtures = {
  apiClient: ApiClient;
  createdUser: User;
  userRegistrationPage: UserRegistrationPage;
  transactionPage: TransactionPage;
};

export const test = base.extend<Fixtures>({
  apiClient: async ({ request }, use) => {
    await use(new ApiClient(request, env.authToken, env.apiBaseUrl));
  },

  createdUser: async ({ apiClient }, use) => {
    const payload = buildUser();
    const response = await apiClient.post('/api/users', payload);
    assertSuccessfulResponse(response, 201);
    const body = await readJson(response);
    assertUserResponse(body);
    await use(body);
  },

  userRegistrationPage: async ({ page }, use) => {
    await use(new UserRegistrationPage(page));
  },

  transactionPage: async ({ page }, use) => {
    await use(new TransactionPage(page));
  },
});

export { expect };
