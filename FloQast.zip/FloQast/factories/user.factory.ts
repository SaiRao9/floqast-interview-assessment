import type { AccountType, CreateUserRequest } from '../types/models';

export function uniqueEmail(prefix = 'qa.user'): string {
  const stamp = `${Date.now()}.${Math.random().toString(36).slice(2, 8)}`;
  return `${prefix}.${stamp}@example.com`;
}

export function buildUser(overrides: Partial<CreateUserRequest> = {}): CreateUserRequest {
  return {
    name: 'Jane Doe',
    email: uniqueEmail(),
    accountType: 'premium' as AccountType,
    ...overrides,
  };
}
