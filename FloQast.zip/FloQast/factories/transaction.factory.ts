import type { CreateTransactionRequest, TransactionType } from '../types/models';

export function buildTransaction(
  overrides: Partial<CreateTransactionRequest> = {},
): CreateTransactionRequest {
  return {
    userId: '00000000-0000-4000-8000-000000000001',
    amount: 100.5,
    type: 'transfer' as TransactionType,
    recipientId: '00000000-0000-4000-8000-000000000002',
    ...overrides,
  };
}
