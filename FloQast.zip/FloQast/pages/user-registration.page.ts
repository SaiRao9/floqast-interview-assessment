import type { Page, Locator } from '@playwright/test';
import type { CreateUserRequest } from '../types/models';

export class UserRegistrationPage {
  readonly nameInput: Locator;
  readonly emailInput: Locator;
  readonly accountTypeSelect: Locator;
  readonly registerButton: Locator;
  readonly successMessage: Locator;
  readonly errorMessage: Locator;

  constructor(private readonly page: Page) {
    this.nameInput = page.getByTestId('name-input');
    this.emailInput = page.getByTestId('email-input');
    this.accountTypeSelect = page.getByTestId('account-type-select');
    this.registerButton = page.getByTestId('register-button');
    this.successMessage = page.getByTestId('success-message');
    this.errorMessage = page.getByTestId('error-message');
  }

  async goto(): Promise<void> {
    await this.page.goto('/register.html');
  }

  async register(user: Partial<CreateUserRequest>): Promise<void> {
    if (user.name !== undefined) {
      await this.nameInput.fill(user.name);
    }
    if (user.email !== undefined) {
      await this.emailInput.fill(user.email);
    }
    if (user.accountType !== undefined) {
      await this.accountTypeSelect.selectOption(user.accountType);
    }
    await this.registerButton.click();
  }
}
