import type { Page, Locator } from '@playwright/test';
import type { CreateTransactionRequest } from '../types/models';

export class TransactionPage {
  readonly userIdInput: Locator;
  readonly amountInput: Locator;
  readonly typeSelect: Locator;
  readonly recipientIdInput: Locator;
  readonly createButton: Locator;
  readonly successMessage: Locator;
  readonly errorMessage: Locator;

  constructor(private readonly page: Page) {
    this.userIdInput = page.getByTestId('user-id-input');
    this.amountInput = page.getByTestId('amount-input');
    this.typeSelect = page.getByTestId('type-select');
    this.recipientIdInput = page.getByTestId('recipient-id-input');
    this.createButton = page.getByTestId('create-transaction-button');
    this.successMessage = page.getByTestId('success-message');
    this.errorMessage = page.getByTestId('error-message');
  }

  async goto(): Promise<void> {
    await this.page.goto('/transactions.html');
  }

  async create(transaction: Partial<CreateTransactionRequest> & { amount?: number | string }): Promise<void> {
    if (transaction.userId !== undefined) {
      await this.userIdInput.fill(transaction.userId);
    }
    if (transaction.amount !== undefined) {
      await this.amountInput.fill(String(transaction.amount));
    }
    if (transaction.type !== undefined) {
      await this.typeSelect.selectOption(transaction.type);
    }
    if (transaction.recipientId !== undefined) {
      await this.recipientIdInput.fill(transaction.recipientId);
    }
    await this.createButton.click();
  }
}
