import { randomUUID } from 'crypto';
import { buildUser } from '../../factories/user.factory';
import { expect, test } from '../../fixtures/test.fixture';
import { assertSuccessfulResponse } from '../../utils/assertions';

test.describe('UI error handling', () => {
  test('displays the API error when registering a duplicate email', async ({
    apiClient,
    userRegistrationPage,
  }) => {
    const payload = buildUser();
    const created = await apiClient.post('/api/users', payload);
    assertSuccessfulResponse(created, 201);

    await userRegistrationPage.goto();
    await userRegistrationPage.register(payload);

    await expect(userRegistrationPage.errorMessage).toBeVisible();
    await expect(userRegistrationPage.errorMessage).toContainText(/already exists/i);
    await expect(userRegistrationPage.successMessage).toBeHidden();
  });

  test('displays the API error when the user ID does not exist', async ({ transactionPage }) => {
    await transactionPage.goto();
    await transactionPage.create({
      userId: randomUUID(),
      amount: 20,
      type: 'transfer',
      recipientId: randomUUID(),
    });

    await expect(transactionPage.errorMessage).toBeVisible();
    await expect(transactionPage.errorMessage).toContainText(/does not exist|not found/i);
    await expect(transactionPage.successMessage).toBeHidden();
  });
});
