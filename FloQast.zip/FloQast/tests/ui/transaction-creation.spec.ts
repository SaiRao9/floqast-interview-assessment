import { buildUser } from '../../factories/user.factory';
import { expect, test } from '../../fixtures/test.fixture';
import { assertSuccessfulResponse, assertUserResponse, readJson } from '../../utils/assertions';

test.describe('Transaction creation UI', () => {
  test('creates a transaction and shows a success message', async ({
    apiClient,
    createdUser,
    transactionPage,
  }) => {
    const recipientResponse = await apiClient.post('/api/users', buildUser({ name: 'Riley Recipient' }));
    assertSuccessfulResponse(recipientResponse, 201);
    const recipient = await readJson(recipientResponse);
    assertUserResponse(recipient);

    await transactionPage.goto();
    await transactionPage.create({
      userId: createdUser.id,
      amount: 100.5,
      type: 'transfer',
      recipientId: recipient.id,
    });

    await expect(transactionPage.successMessage).toBeVisible();
    await expect(transactionPage.successMessage).toContainText(/transaction created successfully/i);
    await expect(transactionPage.errorMessage).toBeHidden();
  });

  test('shows a validation error for an invalid amount', async ({ createdUser, transactionPage }) => {
    await transactionPage.goto();
    await transactionPage.create({
      userId: createdUser.id,
      amount: -5,
      type: 'transfer',
      recipientId: createdUser.id,
    });

    await expect(transactionPage.errorMessage).toBeVisible();
    await expect(transactionPage.errorMessage).toContainText(/amount/i);
    await expect(transactionPage.successMessage).toBeHidden();
  });

  test('shows validation errors when required fields are empty', async ({ transactionPage }) => {
    await transactionPage.goto();
    await transactionPage.createButton.click();

    await expect(transactionPage.errorMessage).toBeVisible();
    await expect(transactionPage.errorMessage).toContainText(/required/i);
    await expect(transactionPage.successMessage).toBeHidden();
  });
});
