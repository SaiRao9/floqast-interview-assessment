import { buildUser } from '../../factories/user.factory';
import { expect, test } from '../../fixtures/test.fixture';

test.describe('User registration UI', () => {
  test('registers a new user and shows a success message', async ({ userRegistrationPage }) => {
    const payload = buildUser({ name: 'John Doe', accountType: 'premium' });

    await userRegistrationPage.goto();
    await userRegistrationPage.register(payload);

    await expect(userRegistrationPage.successMessage).toBeVisible();
    await expect(userRegistrationPage.successMessage).toContainText(/registered successfully/i);
    await expect(userRegistrationPage.errorMessage).toBeHidden();
  });

  test('shows validation errors when required fields are empty', async ({ userRegistrationPage }) => {
    await userRegistrationPage.goto();
    await userRegistrationPage.registerButton.click();

    await expect(userRegistrationPage.errorMessage).toBeVisible();
    await expect(userRegistrationPage.errorMessage).toContainText(/required/i);
    await expect(userRegistrationPage.successMessage).toBeHidden();
  });

  test('shows a validation error for an invalid email', async ({ userRegistrationPage }) => {
    await userRegistrationPage.goto();
    await userRegistrationPage.register({
      name: 'Bad Email',
      email: 'not-an-email',
      accountType: 'basic',
    });

    await expect(userRegistrationPage.errorMessage).toBeVisible();
    await expect(userRegistrationPage.errorMessage).toContainText(/invalid email/i);
    await expect(userRegistrationPage.successMessage).toBeHidden();
  });
});
