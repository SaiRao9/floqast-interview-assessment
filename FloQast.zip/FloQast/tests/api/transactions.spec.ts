import { randomUUID } from 'crypto';
import { buildTransaction } from '../../factories/transaction.factory';
import { buildUser } from '../../factories/user.factory';
import { expect, test } from '../../fixtures/test.fixture';
import type { User } from '../../types/models';
import { ApiClient } from '../../utils/api-client';
import {
  assertBadRequest,
  assertErrorBody,
  assertNotFound,
  assertSuccessfulResponse,
  assertTransactionResponse,
  assertUserResponse,
  readJson,
} from '../../utils/assertions';

async function createSecondUser(apiClient: ApiClient): Promise<User> {
  const response = await apiClient.post('/api/users', buildUser({ name: 'Alex Recipient' }));
  assertSuccessfulResponse(response, 201);
  const body = await readJson(response);
  assertUserResponse(body);
  return body;
}

test.describe('Transaction API', () => {
  test.describe('POST /api/transactions', () => {
    test('creates a transaction with a valid payload', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const payload = buildTransaction({
        userId: createdUser.id,
        recipientId: recipient.id,
        amount: 100.5,
        type: 'transfer',
      });

      const response = await apiClient.post('/api/transactions', payload);

      assertSuccessfulResponse(response, 201);
      const body = await readJson(response);
      assertTransactionResponse(body);
      expect(body.userId).toBe(payload.userId);
      expect(body.recipientId).toBe(payload.recipientId);
      expect(body.amount).toBe(payload.amount);
      expect(body.type).toBe(payload.type);
      expect(body.status).toBe('completed');
    });

    test('rejects a missing userId', async ({ apiClient, createdUser }) => {
      const response = await apiClient.post('/api/transactions', {
        amount: 25,
        type: 'transfer',
        recipientId: createdUser.id,
      });

      assertBadRequest(response);
      assertErrorBody(await readJson(response), 'userId');
    });

    test('rejects a non-numeric amount', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const response = await apiClient.post('/api/transactions', {
        userId: createdUser.id,
        amount: '100.50',
        type: 'transfer',
        recipientId: recipient.id,
      });

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /amount/i);
    });

    test('rejects a zero amount', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const response = await apiClient.post(
        '/api/transactions',
        buildTransaction({ userId: createdUser.id, recipientId: recipient.id, amount: 0 }),
      );

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /amount/i);
    });

    test('rejects a negative amount', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const response = await apiClient.post(
        '/api/transactions',
        buildTransaction({ userId: createdUser.id, recipientId: recipient.id, amount: -10 }),
      );

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /amount/i);
    });

    test('rejects an invalid transaction type', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const response = await apiClient.post('/api/transactions', {
        ...buildTransaction({ userId: createdUser.id, recipientId: recipient.id }),
        type: 'wire',
      });

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /type/i);
    });

    test('rejects a missing recipientId', async ({ apiClient, createdUser }) => {
      const response = await apiClient.post('/api/transactions', {
        userId: createdUser.id,
        amount: 50,
        type: 'transfer',
      });

      assertBadRequest(response);
      assertErrorBody(await readJson(response), 'recipientId');
    });
  });

  test.describe('GET /api/transactions/:userId', () => {
    test('returns transactions for a valid user', async ({ apiClient, createdUser }) => {
      const recipient = await createSecondUser(apiClient);
      const created = await apiClient.post(
        '/api/transactions',
        buildTransaction({ userId: createdUser.id, recipientId: recipient.id }),
      );
      assertSuccessfulResponse(created, 201);
      const createdBody = await readJson(created);
      assertTransactionResponse(createdBody);

      const response = await apiClient.get(`/api/transactions/${createdUser.id}`);

      assertSuccessfulResponse(response, 200);
      const body = await readJson<unknown[]>(response);
      expect(Array.isArray(body)).toBe(true);
      expect(body).toHaveLength(1);
      assertTransactionResponse(body[0]);
      expect(body[0].id).toBe(createdBody.id);
    });

    test('returns an empty list when the user has no transactions', async ({ apiClient, createdUser }) => {
      const response = await apiClient.get(`/api/transactions/${createdUser.id}`);

      assertSuccessfulResponse(response, 200);
      expect(await readJson(response)).toEqual([]);
    });

    test('returns 404 for an unknown user', async ({ apiClient }) => {
      const response = await apiClient.get(`/api/transactions/${randomUUID()}`);

      assertNotFound(response);
      assertErrorBody(await readJson(response), /not found/i);
    });
  });
});
