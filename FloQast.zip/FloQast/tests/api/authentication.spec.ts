import { tokens } from '../../config/env';
import { buildUser } from '../../factories/user.factory';
import { test } from '../../fixtures/test.fixture';
import {
  assertErrorBody,
  assertForbidden,
  assertSuccessfulResponse,
  assertUnauthorized,
  readJson,
} from '../../utils/assertions';

test.describe('Authentication and authorization', () => {
  test('rejects user creation without a bearer token', async ({ apiClient }) => {
    const response = await apiClient.post('/api/users', buildUser(), { token: null });

    assertUnauthorized(response);
    assertErrorBody(await readJson(response), /missing authentication token/i);
  });

  test('rejects user creation with an invalid bearer token', async ({ apiClient }) => {
    const response = await apiClient.post('/api/users', buildUser(), { token: tokens.invalid });

    assertUnauthorized(response);
    assertErrorBody(await readJson(response), /invalid authentication token/i);
  });

  test('rejects get-user without a bearer token', async ({ apiClient, createdUser }) => {
    const response = await apiClient.get(`/api/users/${createdUser.id}`, { token: null });

    assertUnauthorized(response);
    assertErrorBody(await readJson(response), /missing authentication token/i);
  });

  test('rejects transaction creation without a bearer token', async ({ apiClient }) => {
    const response = await apiClient.post(
      '/api/transactions',
      { userId: '123', amount: 10, type: 'transfer', recipientId: '456' },
      { token: null },
    );

    assertUnauthorized(response);
    assertErrorBody(await readJson(response), /missing authentication token/i);
  });

  test('rejects get-transactions without a bearer token', async ({ apiClient, createdUser }) => {
    const response = await apiClient.get(`/api/transactions/${createdUser.id}`, { token: null });

    assertUnauthorized(response);
    assertErrorBody(await readJson(response), /missing authentication token/i);
  });

  test('allows a user-role token to create a user', async ({ apiClient }) => {
    const response = await apiClient.post('/api/users', buildUser(), { token: tokens.user });

    assertSuccessfulResponse(response, 201);
  });

  test('forbids a user-role token from resetting store data', async ({ apiClient }) => {
    const response = await apiClient.post('/api/test/reset', {}, { token: tokens.user });

    assertForbidden(response);
    assertErrorBody(await readJson(response), /admin/i);
  });
});
