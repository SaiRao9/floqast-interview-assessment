import { randomUUID } from 'crypto';
import { buildUser } from '../../factories/user.factory';
import { expect, test } from '../../fixtures/test.fixture';
import {
  assertBadRequest,
  assertConflict,
  assertErrorBody,
  assertNotFound,
  assertSuccessfulResponse,
  assertUserResponse,
  readJson,
} from '../../utils/assertions';

test.describe('User API', () => {
  test.describe('POST /api/users', () => {
    test('creates a user with a valid payload', async ({ apiClient }) => {
      const payload = buildUser({ name: 'John Doe', accountType: 'premium' });

      const response = await apiClient.post('/api/users', payload);

      assertSuccessfulResponse(response, 201);
      const body = await readJson(response);
      assertUserResponse(body);
      expect(body.name).toBe(payload.name);
      expect(body.email).toBe(payload.email.toLowerCase());
      expect(body.accountType).toBe(payload.accountType);
      expect(body.id).toMatch(
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i,
      );
    });

    test('rejects missing required fields', async ({ apiClient }) => {
      const missingName = await apiClient.post('/api/users', {
        email: buildUser().email,
        accountType: 'premium',
      });
      assertBadRequest(missingName);
      assertErrorBody(await readJson(missingName), 'name');

      const missingEmail = await apiClient.post('/api/users', {
        name: 'No Email',
        accountType: 'standard',
      });
      assertBadRequest(missingEmail);
      assertErrorBody(await readJson(missingEmail), 'email');
    });

    test('rejects an invalid email address', async ({ apiClient }) => {
      const response = await apiClient.post('/api/users', buildUser({ email: 'not-an-email' }));

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /email/i);
    });

    test('rejects an invalid accountType', async ({ apiClient }) => {
      const response = await apiClient.post('/api/users', {
        ...buildUser(),
        accountType: 'gold',
      });

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /accountType/i);
    });

    test('rejects a duplicate email', async ({ apiClient }) => {
      const payload = buildUser();
      const first = await apiClient.post('/api/users', payload);
      assertSuccessfulResponse(first, 201);

      const duplicate = await apiClient.post('/api/users', { ...payload, name: 'Other Person' });

      assertConflict(duplicate);
      assertErrorBody(await readJson(duplicate), /already exists/i);
    });

    test('rejects a missing request body', async ({ apiClient }) => {
      const response = await apiClient.post('/api/users', {});

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /request body/i);
    });
  });

  test.describe('GET /api/users/:id', () => {
    test('returns an existing user', async ({ apiClient, createdUser }) => {
      const response = await apiClient.get(`/api/users/${createdUser.id}`);

      assertSuccessfulResponse(response, 200);
      const body = await readJson(response);
      assertUserResponse(body);
      expect(body.id).toBe(createdUser.id);
      expect(body.email).toBe(createdUser.email);
    });

    test('returns 404 when the user does not exist', async ({ apiClient }) => {
      const response = await apiClient.get(`/api/users/${randomUUID()}`);

      assertNotFound(response);
      assertErrorBody(await readJson(response), /not found/i);
    });

    test('returns 400 for an invalid user ID', async ({ apiClient }) => {
      const response = await apiClient.get('/api/users/not-a-uuid');

      assertBadRequest(response);
      assertErrorBody(await readJson(response), /invalid user id/i);
    });
  });
});
