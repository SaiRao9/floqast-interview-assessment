# Test Strategy

## Purpose

This document describes the testing strategy for the hypothetical fintech platform (User, Transaction, and Notification services behind an API Gateway). The executable suite in this repository targets a local mock of the supplied Create/Read APIs. The same test design is intended to transfer to real services by changing `API_BASE_URL` and `UI_BASE_URL`.

## Test pyramid

```
        /\
       /  \        Manual / exploratory (production-like UIs, rare)
      / UI \       Few, high-value browser flows (Playwright)
     /------\
    /  API   \     Majority of functional coverage (Playwright request)
   /----------\
  /  Unit*     \   Service-level unit tests (owned by service teams)
 /--------------\
```

\*This assessment does not include production service source code, so unit tests of domain logic are out of scope. The automation investment is concentrated at the **API** layer, with a thin **UI** layer that proves Page Object structure and user-visible error handling.

| Layer | Tool | Goal | Count in this repo |
| --- | --- | --- | --- |
| API | Playwright `APIRequestContext` | Contract, validation, auth, business rules | 26 |
| UI | Playwright Chromium | Registration, transaction creation, error display | 8 |
| Performance | k6 (strategy + sample, not in `npm test`) | Latency, throughput, error rate | sample only |

## Functional testing strategy

Cover the supplied contract thoroughly:

- **Create**: `POST /api/users`, `POST /api/transactions`
- **Read**: `GET /api/users/:id`, `GET /api/transactions/:userId`

Each successful path asserts HTTP status, payload shape, generated IDs, types, and business values (for example amount > 0, accountType in the allowed set). Negative paths assert status **and** an error body (`error`, `message`, optional `code`).

Tests are independent: they create their own data with unique emails and do not depend on execution order. The mock process holds state in memory; uniqueness avoids collisions under parallel workers.

## API testing strategy

API tests use a shared `ApiClient` so scenarios stay stable if the mock is replaced by a real gateway.

Coverage map:

| Endpoint | Positive | Validation | Auth |
| --- | --- | --- | --- |
| `POST /api/users` | 201 + schema | required fields, email, accountType, duplicate email, empty body | missing / invalid token |
| `GET /api/users/:id` | 200 + schema | invalid ID format, unknown ID | missing token |
| `POST /api/transactions` | 201 + schema | missing userId, invalid/zero/negative amount, type, missing recipientId | missing token |
| `GET /api/transactions/:userId` | list + empty list | unknown user | missing token |

Authorization is demonstrated with a user-role token (allowed to create users) versus an admin-only test harness reset (`POST /api/test/reset` → 403).

### CRUD gap

The assessment asked for CRUD coverage. The supplied production contract only includes **Create** and **Read**. This suite does **not** invent fake Update/Delete product APIs.

When `PUT/PATCH /api/users/:id` and `DELETE /api/users/:id` (and the transaction equivalents) exist, add specs next to the current files. `ApiClient` already exposes `put`, `patch`, and `delete`. Suggested cases:

- Update: valid patch, unknown id (404), invalid payload (400), unauthorized (401), forbidden (403)
- Delete: successful delete then GET 404, unknown id, unauthorized, idempotency if the contract requires it

## UI testing strategy

The mock UI exists only to exercise Page Objects and browser assertions. Tests use `data-testid` selectors via `UserRegistrationPage` and `TransactionPage`.

Flows:

1. Happy-path registration and transaction creation (API success rendered in the page)
2. Client-side required-field and format validation
3. Server errors surfaced to the user (duplicate email, unknown user)

UI tests may call the API client in `before`/fixture setup (create users) so the browser flow is focused on the page, not on data bootstrapping.

## Negative testing

Negative cases are first-class, not afterthoughts:

- Missing and malformed payloads
- Boundary amounts (0, negative)
- Duplicate unique fields (email)
- Unknown and malformed identifiers
- Missing and invalid authentication
- Role restriction (403)

## Authentication / authorization

All `/api/*` routes require `Authorization: Bearer <token>`.

| Token | Role | Access |
| --- | --- | --- |
| `valid-test-token` / `AUTH_TOKEN` | admin | All mock routes |
| `admin-token` | admin | All mock routes |
| `user-token` | user | Product routes; not the admin reset harness |
| anything else / missing | — | 401 |

Tests never hardcode tokens in each spec; they use `config/env.ts` (`tokens`) and the `ApiClient` default header. Credentials are mock values, not production secrets.

## Data validation

Reusable assertions in `utils/assertions.ts`:

- User: `id`, `name`, `email`, `accountType`
- Transaction: `id`, `userId`, `amount`, `type`, `recipientId`, `status`
- Errors: `error` + `message`

The mock enforces the same rules the tests expect (email regex, enum account types, UUID identifiers, amount as a number > 0).

## Test data management

Factories generate payloads with overrides:

- `buildUser()` — unique `qa.user.<timestamp>.<rand>@example.com`
- `buildTransaction()` — defaults plus caller-supplied user/recipient IDs

No shared fixtures of static emails. The `createdUser` Playwright fixture provisions a user per test that needs one.

Cleanup: the in-memory store lives for the mock process lifetime. Unique data makes cleanup optional. `POST /api/test/reset` exists for local debugging (admin token).

## CI/CD strategy

GitHub Actions (`.github/workflows/test.yml`):

1. Checkout, Node 22, `npm ci`
2. Install Chromium
3. Typecheck (`tsc --noEmit`)
4. `npx playwright test` (mock server via Playwright `webServer`)
5. Upload HTML report and `test-results/` (JSON + JUnit)

CI uses one worker and retries failed tests twice. Branch protection should require this workflow plus review of the HTML report on failure.

## Performance testing recommendations

Performance is **not** part of the Playwright functional suite. Use **k6** (or Gatling) against a dedicated environment, never against production without agreement.

### Scenarios

1. `GET /api/users/:id` — read-heavy, cacheable candidate
2. `POST /api/transactions` — write path, consistency and lock risk
3. `GET /api/transactions/:userId` — list path, payload growth
4. Mixed workload — weighted combination of the three

### Load profiles

| Profile | Intent |
| --- | --- |
| Baseline | Single-digit VUs, establish p50/p95 |
| Normal | Expected peak business hour |
| Stress | Ramp past normal until error rate or latency SLO breaks |
| Spike | Sudden 5–10x traffic (payroll / market open) |
| Endurance | Normal load for hours; watch memory/leaks on Node services |

### Signals

- Response time (p95, p99)
- Throughput (successful req/s)
- Error rate (HTTP 5xx and functional 4xx if they indicate overload)
- Saturation (CPU, event-loop lag, Mongo/Redis, gateway)

Example SLOs to negotiate with the service owners: p95 < 500ms for GET user, p95 < 800ms for POST transaction, error rate < 1% under normal load.

A starter script lives at `docs/performance/sample.k6.js`. It is illustrative only:

```bash
k6 run docs/performance/sample.k6.js
```

## Production quality risks

| Risk | Why it matters | Mitigation |
| --- | --- | --- |
| Mock is not Mongo/Redis | Race conditions, persistence, and TTL will not appear locally | Contract tests in CI against a shared dev/stage stack |
| No Update/Delete APIs | Incomplete resource lifecycle; orphans and GDPR gaps | Add APIs + tests before production CRUD claims |
| Notification service untested | Users may not learn about transfers | Subscribe to events / poll notification API when available |
| Bearer token is static | Real auth (JWT expiry, refresh, MFA) unproven | Replace mock auth with the real identity provider in stage |
| In-memory store | Data vanishes on restart; no multi-instance consistency | Use real persistence in integration environments |
| UI is a stand-in | Visual/a11y/responsive issues in the real app are uncovered | Point UI tests at the real frontend when it exists |
| Amount as JSON number | Money should be decimal-safe (integer cents) | Confirm production serialization; add rounding tests |

## Reporting

Functional runs produce:

1. Playwright HTML report (primary)
2. Screenshots / video / trace on UI failure
3. API request/response logs on stdout
4. JSON (`test-results/results.json`)
5. JUnit (`test-results/junit.xml`) for CI dashboards
