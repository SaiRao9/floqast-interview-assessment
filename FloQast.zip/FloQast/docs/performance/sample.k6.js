import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.API_BASE_URL || 'http://localhost:3000';
const TOKEN = __ENV.AUTH_TOKEN || 'valid-test-token';
const headers = {
  Authorization: `Bearer ${TOKEN}`,
  'Content-Type': 'application/json',
};

export const options = {
  scenarios: {
    baseline: {
      executor: 'constant-vus',
      vus: 5,
      duration: '1m',
      exec: 'mixed',
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
  },
};

export function setup() {
  const user = http.post(
    `${BASE_URL}/api/users`,
    JSON.stringify({
      name: 'k6 User',
      email: `k6.${Date.now()}@example.com`,
      accountType: 'standard',
    }),
    { headers },
  );
  const recipient = http.post(
    `${BASE_URL}/api/users`,
    JSON.stringify({
      name: 'k6 Recipient',
      email: `k6.recipient.${Date.now()}@example.com`,
      accountType: 'basic',
    }),
    { headers },
  );
  return { userId: user.json('id'), recipientId: recipient.json('id') };
}

export function mixed(data) {
  const userRes = http.get(`${BASE_URL}/api/users/${data.userId}`, { headers });
  check(userRes, { 'GET user is 200': (r) => r.status === 200 });

  const txnRes = http.post(
    `${BASE_URL}/api/transactions`,
    JSON.stringify({
      userId: data.userId,
      amount: 25.5,
      type: 'transfer',
      recipientId: data.recipientId,
    }),
    { headers },
  );
  check(txnRes, { 'POST transaction is 201': (r) => r.status === 201 });

  const listRes = http.get(`${BASE_URL}/api/transactions/${data.userId}`, { headers });
  check(listRes, { 'GET transactions is 200': (r) => r.status === 200 });

  sleep(1);
}
