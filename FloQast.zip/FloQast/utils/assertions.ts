import { expect, type APIResponse } from '@playwright/test';
import { ACCOUNT_TYPES, TRANSACTION_TYPES } from '../types/models';
import type { ErrorBody, Transaction, User } from '../types/models';

export async function readJson<T = unknown>(response: APIResponse): Promise<T> {
  return (await response.json()) as T;
}

export function assertSuccessfulResponse(response: APIResponse, expectedStatus: 200 | 201 = 200): void {
  expect(response.status(), `Expected ${expectedStatus} but received ${response.status()}`).toBe(expectedStatus);
}

export function assertUnauthorized(response: APIResponse): void {
  expect(response.status()).toBe(401);
}

export function assertForbidden(response: APIResponse): void {
  expect(response.status()).toBe(403);
}

export function assertBadRequest(response: APIResponse): void {
  expect(response.status()).toBe(400);
}

export function assertNotFound(response: APIResponse): void {
  expect(response.status()).toBe(404);
}

export function assertConflict(response: APIResponse): void {
  expect(response.status()).toBe(409);
}

export function assertErrorBody(body: unknown, messageMatch?: string | RegExp): asserts body is ErrorBody {
  expect(body).toEqual(
    expect.objectContaining({
      error: expect.any(String),
      message: expect.any(String),
    }),
  );

  if (messageMatch) {
    const message = (body as ErrorBody).message;
    if (typeof messageMatch === 'string') {
      expect(message).toContain(messageMatch);
    } else {
      expect(message).toMatch(messageMatch);
    }
  }
}

export function assertUserResponse(body: unknown): asserts body is User {
  expect(body).toEqual(
    expect.objectContaining({
      id: expect.any(String),
      name: expect.any(String),
      email: expect.any(String),
      accountType: expect.any(String),
    }),
  );

  const user = body as User;
  expect(user.id.length).toBeGreaterThan(0);
  expect(user.email).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
  expect(ACCOUNT_TYPES).toContain(user.accountType);
}

export function assertTransactionResponse(body: unknown): asserts body is Transaction {
  expect(body).toEqual(
    expect.objectContaining({
      id: expect.any(String),
      userId: expect.any(String),
      amount: expect.any(Number),
      type: expect.any(String),
      recipientId: expect.any(String),
      status: expect.any(String),
    }),
  );

  const txn = body as Transaction;
  expect(txn.id.length).toBeGreaterThan(0);
  expect(txn.amount).toBeGreaterThan(0);
  expect(TRANSACTION_TYPES).toContain(txn.type);
  expect(['pending', 'completed', 'failed']).toContain(txn.status);
}
