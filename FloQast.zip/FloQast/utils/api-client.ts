import type { APIRequestContext, APIResponse } from '@playwright/test';
import { env } from '../config/env';
import { logRequest, logResponse } from './logger';

export interface RequestOptions {
  /**
   * Bearer token. Pass `null` to omit Authorization (unauthorized tests).
   * Defaults to the fixture / env token.
   */
  token?: string | null;
  headers?: Record<string, string>;
  data?: unknown;
}

/**
 * Thin wrapper around Playwright's APIRequestContext.
 *
 * Tests talk to this client, not to raw `request.get/post`.
 * Point `API_BASE_URL` at a real gateway to reuse the same scenarios.
 */
export class ApiClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly defaultToken: string = env.authToken,
    private readonly baseURL: string = env.apiBaseUrl,
  ) {}

  get(path: string, options: RequestOptions = {}): Promise<APIResponse> {
    return this.send('GET', path, options);
  }

  post(path: string, data?: unknown, options: RequestOptions = {}): Promise<APIResponse> {
    return this.send('POST', path, { ...options, data });
  }

  put(path: string, data?: unknown, options: RequestOptions = {}): Promise<APIResponse> {
    return this.send('PUT', path, { ...options, data });
  }

  patch(path: string, data?: unknown, options: RequestOptions = {}): Promise<APIResponse> {
    return this.send('PATCH', path, { ...options, data });
  }

  delete(path: string, options: RequestOptions = {}): Promise<APIResponse> {
    return this.send('DELETE', path, options);
  }

  private async send(method: string, path: string, options: RequestOptions): Promise<APIResponse> {
    const url = `${this.baseURL}${path}`;
    const token = options.token === undefined ? this.defaultToken : options.token;
    const headers: Record<string, string> = {
      Accept: 'application/json',
      ...options.headers,
    };

    if (options.data !== undefined) {
      headers['Content-Type'] = headers['Content-Type'] ?? 'application/json';
    }

    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    logRequest(method, path, options.data);

    const response = await this.request.fetch(url, {
      method,
      headers,
      ...(options.data !== undefined ? { data: options.data as Record<string, unknown> } : {}),
      failOnStatusCode: false,
    });

    let parsed: unknown;
    try {
      parsed = await response.json();
    } catch {
      parsed = await response.text();
    }

    logResponse(method, path, response.status(), parsed);
    return response;
  }
}
