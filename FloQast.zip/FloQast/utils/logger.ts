function summarize(body: unknown): string {
  if (body === undefined) {
    return '';
  }
  try {
    const raw = JSON.stringify(body);
    return raw.length > 300 ? `${raw.slice(0, 300)}…` : raw;
  } catch {
    return String(body);
  }
}

export function logRequest(method: string, path: string, body?: unknown): void {
  const payload = body === undefined ? '' : ` body=${summarize(body)}`;
  console.log(`[API] → ${method} ${path}${payload}`);
}

export function logResponse(method: string, path: string, status: number, body?: unknown): void {
  console.log(`[API] ← ${status} ${method} ${path} ${summarize(body)}`);
}
