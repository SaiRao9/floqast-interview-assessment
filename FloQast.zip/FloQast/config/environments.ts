/**
 * Named environment profiles.
 * Only `local` / `test` are fully runnable in this assessment.
 * development and staging are placeholders for a real deployment.
 */
export const environments = {
  local: {
    apiBaseUrl: 'http://localhost:3000',
    uiBaseUrl: 'http://localhost:3000',
  },
  test: {
    apiBaseUrl: 'http://localhost:3000',
    uiBaseUrl: 'http://localhost:3000',
  },
  development: {
    apiBaseUrl: 'https://dev-api.example-fintech.com',
    uiBaseUrl: 'https://dev.example-fintech.com',
  },
  staging: {
    apiBaseUrl: 'https://staging-api.example-fintech.com',
    uiBaseUrl: 'https://staging.example-fintech.com',
  },
} as const;

export type EnvironmentName = keyof typeof environments;
