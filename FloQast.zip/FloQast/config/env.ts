/**
 * Runtime configuration loaded from environment variables.
 * Defaults target the local mock stack so tests run without extra setup.
 *
 * Swap API_BASE_URL / UI_BASE_URL to point tests at real services later.
 */
export const env = {
  environment: process.env.ENVIRONMENT ?? 'local',
  baseUrl: process.env.BASE_URL ?? 'http://localhost:3000',
  uiBaseUrl: process.env.UI_BASE_URL ?? process.env.BASE_URL ?? 'http://localhost:3000',
  apiBaseUrl: process.env.API_BASE_URL ?? process.env.BASE_URL ?? 'http://localhost:3000',
  authToken: process.env.AUTH_TOKEN ?? 'valid-test-token',
};

export const tokens = {
  valid: env.authToken,
  admin: 'admin-token',
  user: 'user-token',
  invalid: 'invalid-token',
} as const;
